package com.fvbox.util

import android.annotation.SuppressLint
import android.content.Context

@SuppressLint("StaticFieldLeak")
object ContextHolder {

    private lateinit var context: Context

    fun init(context: Context) {
        this.context = context
    }

    fun get(): Context {
        return context
    }
}
