package com.fvbox.hook.modules

import com.fvbox.hook.BaseHook
import android.util.Log

class NetworkPrivacyHook : BaseHook {

    override fun isEnabled(): Boolean = true

    override fun onHandleMethod(className: String, methodName: String, args: Array<Any?>?): Any? {
        return when (methodName) {
            "getNetworkCapabilities" -> {
                // VPN ডিটেকশন লুকানো (TRANSPORT_VPN ফ্ল্যাগ রিমুভ করা)
                null
            }
            "isProxying" -> {
                false
            }
            "getProperty" -> {
                val key = args?.get(0) as? String
                if (key == "http.proxyHost" || key == "http.proxyPort") {
                    return "" // সিস্টেম প্রক্সি হাইড করা
                }
                null
            }
            else -> null
        }
    }
}
