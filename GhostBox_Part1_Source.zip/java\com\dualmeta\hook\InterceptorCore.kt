package com.dualmeta.hook

object InterceptorCore {
    
    // Tracking SDK এর প্যাকেজ নামের লিস্ট
    private val trackingSDKs = listOf(
        "com.adjust.sdk",           // Adjust
        "com.appsflyer",            // AppsFlyer
        "com.facebook.appevents",   // Facebook Analytics
        "com.google.firebase.analytics",
        "com.amplitude.api",
        "com.mixpanel.android"
    )
    
    fun shouldSpoofForPackage(packageName: String): Boolean {
        return trackingSDKs.any { packageName.contains(it) }
    }
    
    fun getSpoofedDeviceId(): String {
        // র্যান্ডম কিন্তু ভ্যালিড IMEI জেনারেট করুন
        return generateRandomIMEI()
    }
    
    fun getSpoofedMacAddress(): String {
        return generateRandomMAC()
    }
    
    fun generateRandomIMEI(): String {
        return (1..15).joinToString("") { (0..9).random().toString() }
    }
    
    fun generateRandomMAC(): String {
        return (1..6).joinToString(":") { String.format("%02X", (0..255).random()) }
    }

    fun generateRandomHexString(length: Int): String {
        val chars = "0123456789abcdef"
        return (1..length).map { chars.random() }.joinToString("")
    }
}
