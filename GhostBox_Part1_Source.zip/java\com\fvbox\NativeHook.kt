package com.fvbox

object NativeHook {
    
    init {
        System.loadLibrary("native_hook")
    }
    
    external fun installHooks(): Int
    external fun getFakeDeviceId(): String
    external fun isMockLocationHidden(): Boolean

    external fun spoofLocationData(latitude: Double, longitude: Double): Boolean

    @Suppress("Unused")
    external fun installInlineHook(targetAddr: Long, newAddr: Long): Int
}
