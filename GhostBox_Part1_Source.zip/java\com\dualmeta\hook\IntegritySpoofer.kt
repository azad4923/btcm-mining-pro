package com.dualmeta.hook

import android.util.Log

object IntegritySpoofer {

    private const val TAG = "IntegritySpoofer"

    // Play Integrity এবং SafetyNet বাইপাস করার জন্য প্রয়োজনীয় সিস্টেম প্রপার্টিজ
    private val spoofedProps = mapOf(
        "ro.boot.flash.locked" to "1",
        "ro.boot.verifiedbootstate" to "green",
        "ro.boot.veritymode" to "enforcing",
        "ro.boot.vbmeta.device_state" to "locked",
        "ro.boot.hw.veritymode" to "enforcing",
        "ro.boot.warranty_bit" to "0",
        "ro.warranty_bit" to "0",
        "ro.build.type" to "user",
        "ro.build.tags" to "release-keys",
        "ro.debuggable" to "0",
        "ro.secure" to "1",
        "ro.expect.recovery_id" to ""
    )

    /**
     * SystemProperties.get() ইন্টারসেপ্ট করার জন্য
     */
    fun getSystemProperty(key: String, def: String?): String? {
        if (spoofedProps.containsKey(key)) {
            val value = spoofedProps[key]
            Log.d(TAG, "Spoofing SystemProperty: $key -> $value")
            return value
        }
        return def
    }

    /**
     * Settings.Global বা Settings.Secure এর ভ্যালু স্পুফ করার জন্য
     */
    fun getSettingsValue(key: String): Any? {
        return when (key) {
            "adb_enabled" -> 0
            "development_settings_enabled" -> 0
            "verifying_allow_debuggable" -> 0
            else -> null
        }
    }

    /**
     * GMS নির্দিষ্ট ইন্টিগ্রিটি চেক বাইপাস
     */
    fun shouldInterceptGms(packageName: String): Boolean {
        return packageName.startsWith("com.google.android.gms") || 
               packageName.startsWith("com.google.android.vending")
    }
}
