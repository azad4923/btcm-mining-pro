package com.fvbox.hook.modules

import com.fvbox.hook.BaseHook
import android.util.Log
import java.io.File

class RootHideHook : BaseHook {

    override fun isEnabled(): Boolean = true

    override fun onHandleMethod(className: String, methodName: String, args: Array<Any?>?): Any? {
        return when (methodName) {
            "exists" -> {
                // su বা busybox ফাইল চেক ব্লক করা
                val path = (args?.get(0) as? String) ?: ""
                if (path.contains("su") || path.contains("busybox") || path.contains("magisk")) {
                    Log.d("RootHideHook", "Blocking root file check: $path")
                    return false
                }
                null
            }
            "getRuntime" -> {
                // Runtime.exec("su") ব্লক করা
                null
            }
            else -> null
        }
    }
}
