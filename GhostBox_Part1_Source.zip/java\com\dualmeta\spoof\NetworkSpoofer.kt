package com.dualmeta.spoof

import java.net.*
import java.io.IOException
import com.fvbox.app.config.BoxConfig

object NetworkSpoofer {
    
    fun applyProxy(userId: Int) {
        val mmkv = BoxConfig.mmkv
        val enable = mmkv.decodeBool("proxy_enable_$userId", false)
        if (!enable) {
            System.clearProperty("socksProxyHost")
            System.clearProperty("socksProxyPort")
            System.clearProperty("http.proxyHost")
            System.clearProperty("http.proxyPort")
            ProxySelector.setDefault(null)
            return
        }

        val host = mmkv.decodeString("proxy_host_$userId", "") ?: ""
        val portStr = mmkv.decodeString("proxy_port_$userId", "1080") ?: "1080"
        val port = portStr.toIntOrNull() ?: 1080
        val user = mmkv.decodeString("proxy_user_$userId", "") ?: ""
        val pass = mmkv.decodeString("proxy_pass_$userId", "") ?: ""

        if (host.isNotEmpty()) {
            // SOCKS Proxy System Properties
            System.setProperty("socksProxyHost", host)
            System.setProperty("socksProxyPort", port.toString())
            
            // HTTP Proxy System Properties
            System.setProperty("http.proxyHost", host)
            System.setProperty("http.proxyPort", port.toString())
            System.setProperty("https.proxyHost", host)
            System.setProperty("https.proxyPort", port.toString())

            // Authenticator for Proxy
            if (user.isNotEmpty()) {
                Authenticator.setDefault(object : Authenticator() {
                    override fun getPasswordAuthentication(): PasswordAuthentication {
                        return PasswordAuthentication(user, pass.toCharArray())
                    }
                })
            }

            // Custom ProxySelector for higher level libraries (like OkHttp)
            val socksProxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress(host, port))
            val httpProxy = Proxy(Proxy.Type.HTTP, InetSocketAddress(host, port))
            
            ProxySelector.setDefault(object : ProxySelector() {
                override fun select(uri: URI?): List<Proxy> {
                    val protocol = uri?.scheme?.lowercase()
                    return if (protocol == "http" || protocol == "https") {
                        listOf(httpProxy)
                    } else {
                        listOf(socksProxy)
                    }
                }

                override fun connectFailed(uri: URI?, sa: SocketAddress?, ioe: IOException?) {
                    // Log error
                }
            })
        }
    }
}
