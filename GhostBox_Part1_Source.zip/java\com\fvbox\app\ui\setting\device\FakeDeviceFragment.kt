package com.fvbox.app.ui.setting.device

import android.os.Bundle
import androidx.core.os.bundleOf
import androidx.fragment.app.viewModels
import com.fvbox.R
import com.dualmeta.hook.InterceptorCore
import com.dualmeta.spoof.BuildPropSpoofer
import com.fvbox.app.base.BaseActivity
import com.fvbox.app.ui.setting.BaseBoxPreference
import com.fvbox.app.ui.setting.ClickPreference
import com.fvbox.app.ui.setting.EditBoxPreference
import com.fvbox.app.ui.setting.PreferenceActivity
import com.fvbox.app.ui.setting.PreferenceFragment
import com.fvbox.app.ui.setting.SingleChoicePreference
import com.fvbox.app.ui.setting.SwitchBoxPreference
import com.fvbox.app.ui.setting.TitleBoxPreference
import com.fvbox.data.state.BoxActionState
import com.fvbox.util.extension.showSnackBar


class FakeDeviceFragment : PreferenceFragment() {

    private lateinit var deviceMapping: DeviceMapping

    private lateinit var languageMapping: LanguageMapping

    private var userID: Int = 0

    private val viewModel by viewModels<FakeDeviceViewModel>()

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        super.onCreatePreferences(savedInstanceState, rootKey)
        observeData()
    }

    override fun initData() {
        userID = requireArguments().getInt(BaseActivity.INTENT_USERID)
        deviceMapping = DeviceMapping(userID)
        languageMapping = LanguageMapping(userID)
    }

    private fun observeData() {
        viewModel.boxActionState.observe(this) {
            when (it) {
                is BoxActionState.Loading -> {
                    attachActivity().showLoadingDialog()
                }

                is BoxActionState.Fail -> {
                    attachActivity().dismissLoadingDialog()
                    showSnackBar(it.msg)
                }

                is BoxActionState.Success -> {
                    deviceMapping.refresh()
                    loadData()
                    attachActivity().dismissLoadingDialog()
                }
            }
        }
    }

    override fun getSettingTypeList(): Array<BaseBoxPreference> {
        return arrayOf(
            TitleBoxPreference(R.string.fake_env),
            SingleChoicePreference(
                R.string.app_language,
                languageMapping.getLanguageList(),
                languageMapping::language
            ),
            SingleChoicePreference(
                R.string.app_country,
                languageMapping.getRegionList(),
                languageMapping::region
            ),
            SingleChoicePreference(
                R.string.app_timezone,
                languageMapping.getTimeZoneList(),
                languageMapping::timeZone
            ),
            TitleBoxPreference(R.string.fake_device_setting),
            SwitchBoxPreference(
                R.string.fake_device_setting,
                R.string.fake_device_enable,
                deviceMapping::enable
            ),
            ClickPreference(R.string.apply_antidetect_profile, 0, this::applyAntiDetectProfile),
            ClickPreference(R.string.origin_device_config, 0, this::originDeviceInfo),
            EditBoxPreference(R.string.fake_device_device, deviceMapping::device),
            EditBoxPreference(R.string.fake_device_board, deviceMapping::board),
            EditBoxPreference(R.string.fake_device_brand, deviceMapping::brand),
            EditBoxPreference(R.string.fake_device_wifiMac, deviceMapping::wifiMac),
            EditBoxPreference(R.string.fake_device_hardware, deviceMapping::hardware),
            EditBoxPreference(R.string.fake_device_manufacturer, deviceMapping::manufacturer),
            EditBoxPreference(R.string.fake_device_product, deviceMapping::product),
            EditBoxPreference(R.string.fake_device_model, deviceMapping::model),
            EditBoxPreference(R.string.fake_device_serial, deviceMapping::serial),
            EditBoxPreference(R.string.fake_device_androidId, deviceMapping::androidId),
            EditBoxPreference(R.string.fake_device_deviceId, deviceMapping::deviceId),
            EditBoxPreference(R.string.fake_device_id, deviceMapping::id),
            EditBoxPreference(R.string.fake_device_bootId, deviceMapping::bootId),
            TitleBoxPreference(R.string.proxy_setting),
            SwitchBoxPreference(
                R.string.proxy_enable,
                R.string.proxy_enable,
                deviceMapping::proxyEnable
            ),
            EditBoxPreference(R.string.proxy_host, deviceMapping::proxyHost),
            EditBoxPreference(R.string.proxy_port, deviceMapping::proxyPort),
            EditBoxPreference(R.string.proxy_user, deviceMapping::proxyUser),
            EditBoxPreference(R.string.proxy_pass, deviceMapping::proxyPass),
        )
    }

    private fun originDeviceInfo() {
        attachActivity().showLoadingDialog()
        viewModel.originDevice(userID)
    }

    private fun applyAntiDetectProfile() {
        BuildPropSpoofer.rotateProfile()
        val profile = BuildPropSpoofer.getCurrentProfile()
        deviceMapping.apply {
            enable = true
            model = profile.model
            manufacturer = profile.manufacturer
            brand = profile.manufacturer
            board = profile.board
            device = profile.device
            hardware = profile.hardware
            product = profile.product
            // Also randomize IDs
            androidId = InterceptorCore.generateRandomHexString(16)
            deviceId = InterceptorCore.generateRandomIMEI()
            wifiMac = InterceptorCore.generateRandomMAC()
            serial = InterceptorCore.generateRandomHexString(10)
        }
        deviceMapping.refresh()
        loadData()
        showSnackBar("Anti-Detect Profile Applied: ${profile.model}")
    }


    private fun attachActivity(): PreferenceActivity {
        return requireActivity() as PreferenceActivity
    }


    companion object {
        fun create(userID: Int): FakeDeviceFragment {
            val fragment = FakeDeviceFragment()
            fragment.arguments = bundleOf(BaseActivity.INTENT_USERID to userID)
            return fragment
        }
    }
}
