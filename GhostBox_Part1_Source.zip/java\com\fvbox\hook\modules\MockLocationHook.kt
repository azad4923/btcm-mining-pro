package com.fvbox.hook.modules

import com.fvbox.hook.BaseHook

class MockLocationHook : BaseHook {

    override fun isEnabled(): Boolean = true

    override fun onHandleMethod(className: String, methodName: String, args: Array<Any?>?): Any? {
        return when (methodName) {
            "isFromMockProvider", "isMock" -> {
                // মক লোকেশন ডিটেকশন বাইপাস (HideMockLocation)
                false
            }
            "getExtras" -> {
                // Bundle থেকে মক ফ্ল্যাগ রিমুভ করা
                null // পরে ইমপ্লিমেন্ট করা যাবে
            }
            else -> null
        }
    }
}
