package com.dualmeta.hook

import com.dualmeta.spoof.BuildPropSpoofer
import com.fvbox.hook.HookManager

object MethodTransformer {

    /**
     * এই মেথডটি যেকোনো মেথড কল ইন্টারসেপ্ট করে এবং প্রোজি ডেটা রিটার্ন করে।
     */
    fun transformMethodCall(className: String, methodName: String, packageName: String): Any? {
        
        // ১. মডিউলার হুক ম্যানেজার (LSPosed স্টাইল)
        val hookResult = HookManager.handleHook(className, methodName, packageName)
        if (hookResult != null) return hookResult

        // ২. Play Integrity / SafetyNet Bypass (GMS টার্গেটেড)
        if (IntegritySpoofer.shouldInterceptGms(packageName)) {
            when (className) {
                "android.os.SystemProperties" -> { }
                "android.provider.Settings\$Global", "android.provider.Settings\$Secure" -> { }
            }
        }

        // ৩. Tracking SDK এর জন্য ডিভাইস ইনফো স্পুফিং
        if (InterceptorCore.shouldSpoofForPackage(packageName)) {
            when (methodName) {
                "getDeviceId" -> return InterceptorCore.getSpoofedDeviceId()
                "getMacAddress" -> return InterceptorCore.getSpoofedMacAddress()
                "getAndroidId" -> return InterceptorCore.generateRandomHexString(16)
            }
        }

        // ৪. Build Prop Spoofing (Samsung S24 প্রোফাইল)
        if (className == "android.os.Build") {
            return BuildPropSpoofer.getSpoofedBuildField(methodName)
        }

        return null
    }
}
