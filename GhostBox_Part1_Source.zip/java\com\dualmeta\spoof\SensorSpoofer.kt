package com.dualmeta.spoof

object SensorSpoofer {
    
    fun getSpoofedSensorData(): FloatArray {
        // রিয়েলিস্টিক সেন্সর ডাটা জেনারেট করুন (ছোট ছোট এলোমেলো পরিবর্তন)
        return floatArrayOf(
            (Math.random() * 10 - 5).toFloat(),  // X axis
            (Math.random() * 10 - 5).toFloat(),  // Y axis
            (Math.random() * 10 - 5).toFloat()   // Z axis
        )
    }
}
