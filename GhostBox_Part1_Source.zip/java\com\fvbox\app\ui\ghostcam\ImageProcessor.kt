package com.fvbox.app.ui.ghostcam

import android.content.Context
import android.graphics.*
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions

object ImageProcessor {

    // ১. Noise Addition (সহজ ও কার্যকর)
    fun addNoise(bitmap: Bitmap, intensity: Float = 5f): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val output = Bitmap.createBitmap(width, height, bitmap.config)
        
        for (x in 0 until width) {
            for (y in 0 until height) {
                val pixel = bitmap.getPixel(x, y)
                val r = (Color.red(pixel) + (Math.random() * intensity).toInt()).coerceIn(0, 255)
                val g = (Color.green(pixel) + (Math.random() * intensity).toInt()).coerceIn(0, 255)
                val b = (Color.blue(pixel) + (Math.random() * intensity).toInt()).coerceIn(0, 255)
                output.setPixel(x, y, Color.rgb(r, g, b))
            }
        }
        return output
    }

    // ২. Gaussian Blur (হালকা ঝাপসা)
    fun applyGaussianBlur(context: Context, bitmap: Bitmap, radius: Float = 1.2f): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        val renderScript = RenderScript.create(context)
        val input = Allocation.createFromBitmap(renderScript, bitmap)
        val allocationOutput = Allocation.createTyped(renderScript, input.type)
        val script = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
        
        script.setInput(input)
        script.setRadius(radius)
        script.forEach(allocationOutput)
        allocationOutput.copyTo(output)
        
        renderScript.destroy()
        return output
    }

    // ৩. Pixel Shifting (১-২ পিক্সেল সরানো)
    fun shiftPixels(bitmap: Bitmap, dx: Int = 1, dy: Int = 1): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val output = Bitmap.createBitmap(width, height, bitmap.config)
        val canvas = Canvas(output)
        canvas.drawBitmap(bitmap, dx.toFloat(), dy.toFloat(), null)
        return output
    }

    // ৪. Color Space Conversion (RGB → HSV → RGB)
    fun shakeColorSpace(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val output = Bitmap.createBitmap(width, height, bitmap.config)
        
        for (x in 0 until width) {
            for (y in 0 until height) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                
                // RGB to HSV
                val hsv = FloatArray(3)
                Color.RGBToHSV(r, g, b, hsv)
                
                // স্যাচুরেশন +২%, ভ্যালু +১% (হালকা পরিবর্তন)
                hsv[1] = (hsv[1] * 1.02f).coerceIn(0f, 1f)
                hsv[2] = (hsv[2] * 1.01f).coerceIn(0f, 1f)
                
                // HSV to RGB
                val newColor = Color.HSVToColor(hsv)
                output.setPixel(x, y, newColor)
            }
        }
        return output
    }

    // ৫. AI Face Modification - Subtle changes to face areas
    fun subtleFaceModification(bitmap: Bitmap, onComplete: (Bitmap) -> Unit) {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .build()
        val detector = FaceDetection.getClient(options)
        val image = InputImage.fromBitmap(bitmap, 0)
        
        detector.process(image)
            .addOnSuccessListener { faces ->
                val mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                for (face in faces) {
                    val bounds = face.boundingBox
                    modifyPixelsInBox(mutableBitmap, bounds)
                }
                onComplete(mutableBitmap)
            }
            .addOnFailureListener {
                onComplete(bitmap)
            }
    }

    private fun modifyPixelsInBox(bitmap: Bitmap, rect: Rect) {
        val intensity = 3f
        val startX = rect.left.coerceAtLeast(0)
        val startY = rect.top.coerceAtLeast(0)
        val endX = rect.right.coerceAtMost(bitmap.width - 1)
        val endY = rect.bottom.coerceAtMost(bitmap.height - 1)

        for (x in startX..endX step 5) {
            for (y in startY..endY step 5) {
                if (x < bitmap.width && y < bitmap.height) {
                    val pixel = bitmap.getPixel(x, y)
                    val r = (Color.red(pixel) + (Math.random() * intensity).toInt()).coerceIn(0, 255)
                    val g = (Color.green(pixel) + (Math.random() * intensity).toInt()).coerceIn(0, 255)
                    val b = (Color.blue(pixel) + (Math.random() * intensity).toInt()).coerceIn(0, 255)
                    bitmap.setPixel(x, y, Color.rgb(r, g, b))
                }
            }
        }
    }

    // ৬. প্রধান প্রসেসিং পাইপলাইন (সব একসাথে)
    fun fullHashBreakPipeline(context: Context, originalBitmap: Bitmap, onComplete: (Bitmap) -> Unit) {
        // Run complex tasks
        var processed = addNoise(originalBitmap, 5f)          // নয়েজ যোগ
        processed = shiftPixels(processed, 1, 1)              // পিক্সেল শিফট
        processed = shakeColorSpace(processed)                // কালার স্পেস পরিবর্তন
        processed = applyGaussianBlur(context, processed, 1.2f) // হালকা ঝাপসা
        
        // ৫% ক্রপ (পিক্সেল কাটা)
        val cropPercent = 0.05f
        val cropWidth = (processed.width * cropPercent).toInt()
        val cropHeight = (processed.height * cropPercent).toInt()
        processed = Bitmap.createBitmap(
            processed,
            cropWidth, cropHeight,
            processed.width - cropWidth * 2,
            processed.height - cropHeight * 2
        )
        
        // ৫% রিসাইজ
        val scale = 0.95f
        val newWidth = (processed.width * scale).toInt()
        val newHeight = (processed.height * scale).toInt()
        val finalProcessed = Bitmap.createScaledBitmap(processed, newWidth, newHeight, true)
        
        // AI Face Mod (Async)
        subtleFaceModification(finalProcessed) { aiProcessed ->
            onComplete(aiProcessed)
        }
    }
}
