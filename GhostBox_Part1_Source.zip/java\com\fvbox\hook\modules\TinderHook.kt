package com.fvbox.hook.modules

import com.fvbox.hook.BaseHook

class TinderHook : BaseHook {

    override fun isEnabled(): Boolean = true

    override fun getTargetPackage(): String = "com.tinder"

    override fun onHandleMethod(className: String, methodName: String, args: Array<Any?>?): Any? {
        return when (methodName) {
            "getScanResults" -> {
                // Tinder যাতে আসল ওয়াইফাই লিস্ট না পায়
                ArrayList<android.net.wifi.ScanResult>()
            }
            "getAllCellInfo", "getNeighboringCellInfo" -> {
                // সেল টাওয়ার ইনফো হাইড করা
                ArrayList<android.telephony.CellInfo>()
            }
            "getDeviceId" -> {
                // Tinder-এর জন্য স্পেসিফিক ফেইক আইডি (যদি প্রয়োজন হয়)
                null
            }
            else -> null
        }
    }
}
