package com.fvbox.hook

import com.fvbox.hook.modules.MockLocationHook
import com.fvbox.hook.modules.TinderHook
import com.fvbox.hook.modules.SensorHook
import com.fvbox.hook.modules.TrackingBlockHook
import com.fvbox.hook.modules.RootHideHook
import com.fvbox.hook.modules.NetworkPrivacyHook

object HookManager {
    
    private val hooks = mutableListOf<BaseHook>()

    init {
        // মডিউলগুলো রেজিস্টার করুন
        hooks.add(MockLocationHook())
        hooks.add(TinderHook())
        hooks.add(SensorHook())
        hooks.add(TrackingBlockHook())
        hooks.add(RootHideHook())
        hooks.add(NetworkPrivacyHook())
    }

    /**
     * ইঞ্জিনের কল ইন্টারসেপ্ট করে সঠিক মডিউলে পাঠায়
     */
    fun handleHook(className: String, methodName: String, packageName: String, args: Array<Any?>? = null): Any? {
        for (hook in hooks) {
            if (hook.isEnabled()) {
                // যদি প্যাকেজ স্পেসিফিক হয়
                val target = hook.getTargetPackage()
                if (target != null && target != packageName) {
                    continue
                }
                
                val result = hook.onHandleMethod(className, methodName, args)
                if (result != null) {
                    return result
                }
            }
        }
        return null
    }
}
