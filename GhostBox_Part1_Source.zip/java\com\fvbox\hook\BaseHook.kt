package com.fvbox.hook

import java.lang.reflect.Member

interface BaseHook {
    /**
     * হুকটি সক্রিয় কিনা তা নির্ধারণ করে
     */
    fun isEnabled(): Boolean

    /**
     * কোন প্যাকেজের জন্য এই হুকটি কাজ করবে
     */
    fun getTargetPackage(): String? = null

    /**
     * মেথড ইন্টারসেপ্ট করার লজিক
     */
    fun onHandleMethod(className: String, methodName: String, args: Array<Any?>?): Any?
}
