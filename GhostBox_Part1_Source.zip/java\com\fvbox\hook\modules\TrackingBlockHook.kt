package com.fvbox.hook.modules

import com.fvbox.hook.BaseHook
import android.util.Log

class TrackingBlockHook : BaseHook {

    private val blockedPackages = listOf(
        "com.adjust.sdk",
        "com.appsflyer",
        "com.facebook.appevents",
        "com.google.firebase.analytics",
        "com.amplitude.api"
    )

    override fun isEnabled(): Boolean = true

    override fun onHandleMethod(className: String, methodName: String, args: Array<Any?>?): Any? {
        // যদি ক্লাসের নামের মধ্যে ব্লকড SDK এর নাম থাকে
        if (blockedPackages.any { className.contains(it) }) {
            Log.d("TrackingBlockHook", "Blocking tracking SDK call: $className.$methodName")
            
            // ট্র্যাকিং কলগুলো ব্লক করতে নাল বা ডিফল্ট ভ্যালু রিটার্ন করুন
            return when (methodName) {
                "trackEvent", "logEvent", "onActivityResumed" -> true
                "getAdvertisingId", "getGaid" -> "00000000-0000-0000-0000-000000000000"
                else -> Unit
            }
        }
        return null
    }
}
