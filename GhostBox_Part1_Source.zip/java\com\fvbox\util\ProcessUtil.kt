package com.fvbox.util

import com.fvbox.lib.FCore

object ProcessUtil {

    fun currentBit(): Int {
        return if (FCore.is64Bit()) {
            64
        } else {
            32
        }
    }

    fun noSupportBit(): Int {
        return if (FCore.is64Bit()) {
            32
        } else {
            64
        }
    }
}
