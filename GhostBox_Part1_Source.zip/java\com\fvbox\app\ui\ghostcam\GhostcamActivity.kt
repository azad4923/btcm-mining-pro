package com.fvbox.app.ui.ghostcam

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.exifinterface.media.ExifInterface
import com.fvbox.R
import com.fvbox.app.base.BaseActivity
import com.fvbox.databinding.ActivityGhostcamBinding
import com.fvbox.util.property.viewBinding
import com.permissionx.guolindev.PermissionX
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class GhostcamActivity : BaseActivity() {

    private val binding by viewBinding(ActivityGhostcamBinding::bind)
    private var selectedImageUri: Uri? = null
    private var cameraImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            selectedImageUri = result.data?.data
            displaySelectedImage()
        }
    }

    private val takePhotoLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            selectedImageUri = cameraImageUri
            displaySelectedImage()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ghostcam)
        setUpToolbar(R.string.ghostcam)

        binding.selectButton.text = getString(R.string.select_image)
        binding.takePhotoButton.text = getString(R.string.take_photo)
        binding.removeButton.text = getString(R.string.remove_metadata)

        binding.selectButton.setOnClickListener {
            checkPermissionAndPickImage()
        }

        binding.takePhotoButton.setOnClickListener {
            checkPermissionAndTakePhoto()
        }

        binding.removeButton.setOnClickListener {
            processAndSaveImage()
        }
    }

    private fun displaySelectedImage() {
        binding.previewImage.setImageURI(selectedImageUri)
        binding.previewImage.alpha = 1.0f
        binding.removeButton.isEnabled = true
        binding.statusText.text = "Image ready for processing."
    }

    private fun checkPermissionAndPickImage() {
        val permissions = mutableListOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
        }
        
        PermissionX.init(this)
            .permissions(permissions)
            .request { allGranted, _, _ ->
                if (allGranted) {
                    val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                    pickImageLauncher.launch(intent)
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun checkPermissionAndTakePhoto() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        PermissionX.init(this)
            .permissions(permissions)
            .request { allGranted, _, _ ->
                if (allGranted) {
                    val photoFile = File(getExternalFilesDir(null), "camera_image_${System.currentTimeMillis()}.jpg")
                    cameraImageUri = androidx.core.content.FileProvider.getUriForFile(
                        this,
                        "${packageName}.provider",
                        photoFile
                    )
                    takePhotoLauncher.launch(cameraImageUri)
                } else {
                    Toast.makeText(this, "Permissions denied", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun processAndSaveImage() {
        val uri = selectedImageUri ?: return
        
        try {
            // 1. Load Bitmap
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap == null) {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                return
            }

            binding.statusText.text = "Processing image (Hash Breaking)..."
            binding.removeButton.isEnabled = false

            // Use the new ImageProcessor Pipeline
            ImageProcessor.fullHashBreakPipeline(this, originalBitmap) { processedBitmap ->
                // 3. Save to temporary file
                val tempFile = File(getExternalFilesDir(null), "processed_${System.currentTimeMillis()}.jpg")
                val fos = FileOutputStream(tempFile)
                processedBitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
                fos.close()

                // 4. Remove EXIF metadata
                removeExif(tempFile.absolutePath)

                // 5. Save to Gallery
                saveToGallery(tempFile)

                runOnUiThread {
                    binding.statusText.text = "Success! Saved to Gallery/GhostBox"
                    Toast.makeText(this, "Image processed and saved to Gallery", Toast.LENGTH_LONG).show()
                    binding.removeButton.isEnabled = true
                }
                
                // Clean up
                originalBitmap.recycle()
                processedBitmap.recycle()
            }

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            binding.removeButton.isEnabled = true
        }
    }

    // Removed the old local processBitmap as it's now in ImageProcessor

    private fun removeExif(filePath: String) {
        val exif = ExifInterface(filePath)
        val attributes = arrayOf(
            ExifInterface.TAG_GPS_LATITUDE,
            ExifInterface.TAG_GPS_LONGITUDE,
            ExifInterface.TAG_GPS_DATESTAMP,
            ExifInterface.TAG_GPS_TIMESTAMP,
            ExifInterface.TAG_GPS_LATITUDE_REF,
            ExifInterface.TAG_GPS_LONGITUDE_REF,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_DATETIME_DIGITIZED,
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_SOFTWARE,
            ExifInterface.TAG_ARTIST,
            ExifInterface.TAG_COPYRIGHT,
            ExifInterface.TAG_USER_COMMENT,
            ExifInterface.TAG_IMAGE_DESCRIPTION
        )

        for (attribute in attributes) {
            exif.setAttribute(attribute, null)
        }
        exif.saveAttributes()
    }

    private fun saveToGallery(file: File) {
        val fileName = "GhostBox_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GhostBox")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val uri = contentResolver.insert(collection, values)
        uri?.let {
            contentResolver.openOutputStream(it)?.use { out ->
                file.inputStream().use { input ->
                    input.copyTo(out)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(it, values, null, null)
            }
            
            // Broadcast for older versions
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, it))
            }
        }
    }

    override fun initImmersionBar() {
    }
}
