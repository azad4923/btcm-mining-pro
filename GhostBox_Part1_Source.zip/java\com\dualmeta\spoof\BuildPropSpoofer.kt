package com.dualmeta.spoof

object BuildPropSpoofer {
    
    // Samsung S24 (SM-S921B) Profile
    private val s24Profile = DeviceProfile(
        model = "SM-S921B",
        manufacturer = "samsung",
        brand = "samsung",
        board = "pineapple",
        device = "e1",
        hardware = "qcom",
        product = "e1s",
        fingerprint = "samsung/e1qxxx/e1q:14/UP1A.231005.007/123456:user/release-keys",
        bootloader = "S921BXXU1AOA7",
        display = "UP1A.231005.007.S921BXXU1AOA7",
        id = "UP1A.231005.007",
        serial = "RZ8X1234567",
        type = "user",
        tags = "release-keys",
        user = "dpi",
        host = "SWDG5712",
        sdk_int = 34,
        version_release = "14",
        version_codename = "REL",
        version_incremental = "S921BXXU1AOA7",
        base_os = "",
        security_patch = "2024-03-01",
        radio_version = "S921BXXU1AOA7",
        supported_abis = arrayOf("arm64-v8a", "armeabi-v7a", "armeabi"),
        supported_32_bit_abis = arrayOf("armeabi-v7a", "armeabi"),
        supported_64_bit_abis = arrayOf("arm64-v8a")
    )

    // Google Pixel 8 Pro (husky) Profile
    private val pixel8ProProfile = DeviceProfile(
        model = "Pixel 8 Pro",
        manufacturer = "Google",
        brand = "google",
        board = "husky",
        device = "husky",
        hardware = "husky",
        product = "husky",
        fingerprint = "google/husky/husky:14/UD1A.230803.041/123456:user/release-keys",
        bootloader = "husky-1.0-123456",
        display = "UD1A.230803.041",
        id = "UD1A.230803.041",
        serial = "P8P123456789",
        type = "user",
        tags = "release-keys",
        user = "android-build",
        host = "google-host",
        sdk_int = 34,
        version_release = "14",
        version_codename = "REL",
        version_incremental = "123456",
        base_os = "",
        security_patch = "2024-04-01",
        radio_version = "g5300q-1.0",
        supported_abis = arrayOf("arm64-v8a", "armeabi-v7a", "armeabi"),
        supported_32_bit_abis = arrayOf("armeabi-v7a", "armeabi"),
        supported_64_bit_abis = arrayOf("arm64-v8a")
    )

    // OnePlus 12 (CPH2581) Profile
    private val onePlus12Profile = DeviceProfile(
        model = "CPH2581",
        manufacturer = "OnePlus",
        brand = "OnePlus",
        board = "pineapple",
        device = "OP592DL1",
        hardware = "qcom",
        product = "CPH2581",
        fingerprint = "OnePlus/CPH2581/OP592DL1:14/UKQ1.230924.001/123456:user/release-keys",
        bootloader = "unknown",
        display = "CPH2581_14.0.0.404(EX01)",
        id = "UKQ1.230924.001",
        serial = "OP1212345678",
        type = "user",
        tags = "release-keys",
        user = "oneplus",
        host = "oneplus-host",
        sdk_int = 34,
        version_release = "14",
        version_codename = "REL",
        version_incremental = "123456",
        base_os = "",
        security_patch = "2024-02-01",
        radio_version = "1.0.c1-12345",
        supported_abis = arrayOf("arm64-v8a", "armeabi-v7a", "armeabi"),
        supported_32_bit_abis = arrayOf("armeabi-v7a", "armeabi"),
        supported_64_bit_abis = arrayOf("arm64-v8a")
    )

    private val profiles = listOf(s24Profile, pixel8ProProfile, onePlus12Profile)
    
    private var currentProfile = s24Profile
    
    fun getSpoofedBuildField(fieldName: String): Any? {
        return when (fieldName) {
            "MODEL" -> currentProfile.model
            "MANUFACTURER" -> currentProfile.manufacturer
            "BRAND" -> currentProfile.brand
            "BOARD" -> currentProfile.board
            "DEVICE" -> currentProfile.device
            "HARDWARE" -> currentProfile.hardware
            "PRODUCT" -> currentProfile.product
            "FINGERPRINT" -> currentProfile.fingerprint
            "BOOTLOADER" -> currentProfile.bootloader
            "DISPLAY" -> currentProfile.display
            "ID" -> currentProfile.id
            "SERIAL" -> currentProfile.serial
            "TYPE" -> currentProfile.type
            "TAGS" -> currentProfile.tags
            "USER" -> currentProfile.user
            "HOST" -> currentProfile.host
            "SDK_INT" -> currentProfile.sdk_int
            "RELEASE" -> currentProfile.version_release
            "CODENAME" -> currentProfile.version_codename
            "INCREMENTAL" -> currentProfile.version_incremental
            "BASE_OS" -> currentProfile.base_os
            "SECURITY_PATCH" -> currentProfile.security_patch
            "RADIO" -> currentProfile.radio_version
            "SUPPORTED_ABIS" -> currentProfile.supported_abis
            "SUPPORTED_32_BIT_ABIS" -> currentProfile.supported_32_bit_abis
            "SUPPORTED_64_BIT_ABIS" -> currentProfile.supported_64_bit_abis
            else -> null
        }
    }

    fun getCurrentProfile(): DeviceProfile = currentProfile

    fun rotateProfile() {
        currentProfile = profiles.random()
    }
}

data class DeviceProfile(
    val model: String,
    val manufacturer: String,
    val brand: String,
    val board: String,
    val device: String,
    val hardware: String,
    val product: String,
    val fingerprint: String,
    val bootloader: String,
    val display: String,
    val id: String,
    val serial: String,
    val type: String,
    val tags: String,
    val user: String,
    val host: String,
    val sdk_int: Int,
    val version_release: String,
    val version_codename: String,
    val version_incremental: String,
    val base_os: String,
    val security_patch: String,
    val radio_version: String,
    val supported_abis: Array<String>,
    val supported_32_bit_abis: Array<String>,
    val supported_64_bit_abis: Array<String>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as DeviceProfile
        if (model != other.model) return false
        return true
    }

    override fun hashCode(): Int {
        return model.hashCode()
    }
}
